const express = require('express');
const router = express.Router();
const Nota = require('../Models/notas'); // Importe o modelo Nota

router.get('/', async (req, res) => {
  try {
    const result = await Nota.find(); // Consulta todas as notas usando o modelo Nota
    res.send(result); // Envia as notas encontradas como resposta
  } catch (error) {
    console.error('Erro ao consultar dados:', error);
    res.status(500).send('Erro ao consultar dados');
  }
});

router.get('/:codigo', async (req, res) => {
  const codigo = req.params.codigo;
  try {
    const nota = await Nota.findOne({ codigoDisciplina:codigo });
    if (nota) {
      res.json(nota);
    } else {
      res.status(404).send('Erro: Disciplina não encontrada');
    }
  } catch (error) {
    console.error('Erro ao consultar dados:', error);
    res.status(500).send('Erro ao consultar dados');
  }
});


router.post('/', async (req, res) => {
  const { codigo, nomeDisciplina, nomeProfessor, nota } = req.body;
  try {
    const novaNota = new Nota({ codigoDisciplina: codigo, nomeDisciplina, nomeProfessor, nota });
    await novaNota.save();
    res.status(200).send('Documento inserido com sucesso');
  } catch (error) {
    console.error('Erro ao inserir documento:', error);
    res.status(500).send('Erro ao inserir documento');
  }
});

router.patch('/:codigo', async (req, res) => {
  const codigo = req.params.codigo;
  const { nomeDisciplina, nomeProfessor, nota } = req.body;
  try {
    const notaAtualizada = await Nota.findOneAndUpdate(
      { codigoDisciplina: codigo },
      { nomeDisciplina, nomeProfessor, nota },
      { new: true }
    );
    if (notaAtualizada) {
      res.status(200).send('Documento atualizado com sucesso');
    } else {
      res.status(404).send('Erro: Disciplina não encontrada');
    }
  } catch (error) {
    console.error('Erro ao atualizar documento:', error);
    res.status(500).send('Erro ao atualizar documento');
  }
});

router.delete('/:codigo', async (req, res) => {
  const codigo = req.params.codigo;
  try {
    const resultado = await Nota.deleteOne({ codigoDisciplina: codigo });
    if (resultado.deletedCount > 0) {
      res.status(200).send('Documento excluído com sucesso');
    } else {
      res.status(404).send('Erro: Disciplina não encontrada');
    }
  } catch (error) {
    console.error('Erro ao excluir documento:', error);
    res.status(500).send('Erro ao excluir documento');
  }
});

module.exports = router;