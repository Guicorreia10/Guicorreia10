const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const notasSchema = new Schema({
  codigoDisciplina: { type: Number, required: [true, 'Código da disciplina obrigatório'], unique: true },
  nomeProfessor: { type: String, required: [true, 'Nome do professor obrigatório'] },
  nomeDisciplina: { type: String, required: [true, 'Nome da disciplina obrigatório'] },
  nota: { type: Number, min: [0, 'A nota mínima é 0'], max: [20, 'A nota máxima é 20'], required: [true, 'Nota obrigatória'] }
}, { timestamps: true });

module.exports = mongoose.model('Nota', notasSchema);