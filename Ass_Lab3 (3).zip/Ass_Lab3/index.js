const express = require('express');
const app = express();

// Middleware para registrar os pedidos recebidos
app.use((req, res, next) => {
  const dataHora = new Date().toLocaleString(); // Obter a data e hora atual formatada
  const metodo = req.method; // Obter o método da requisição
  const url = req.url; // Obter a URL da requisição
  console.log(`[${dataHora}] Pedido ${metodo} recebido em ${url}`);
  next(); // Chama o próximo middleware na cadeia
});

// Importar o arquivo notas.js

const notasRouter = require('./Controllers/notasmongo');

// Middleware para o corpo das requisições em formato JSON
app.use(express.json());

// Rotas relacionadas às notas
app.use('/notas', notasRouter);


// Código para a conexão à base de dados usando o Mongoose
const mongoose = require('mongoose');
const url = 'mongodb://localhost:27017/';

mongoose.connect(url);
const connection = mongoose.connection;
connection.once('open', () => {
  console.log('MongoDB database connection established successfully');
  });
connection.on('error', (error) => {
  console.error('Erro na conexão com o banco de dados:', error);
  });

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Assessment Lab 2 - José Bispo e Guilherme Correia`);
});
